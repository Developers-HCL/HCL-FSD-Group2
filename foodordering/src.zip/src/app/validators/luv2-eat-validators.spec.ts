import { Luv2EatValidators } from './luv2-eat-validators';

describe('Luv2EatValidators', () => {
  it('should create an instance', () => {
    expect(new Luv2EatValidators()).toBeTruthy();
  });
});
